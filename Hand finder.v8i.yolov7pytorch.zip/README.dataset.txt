# Hand finder > 2023-11-28 12:43pm
https://universe.roboflow.com/termpoject/hand-finder-to2uu

Provided by a Roboflow user
License: CC BY 4.0

